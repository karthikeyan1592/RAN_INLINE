#!/usr/bin/env python3
"""Generate publication-quality figures from PoC measurement CSVs."""

import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

SLOT_BUDGET_US = 500


def load_latency(path):
    df = pd.read_csv(path)
    return df["latency_us"].astype(float)


def plot_cdf(baseline, offload, out_dir):
    fig, ax = plt.subplots(figsize=(3.5, 2.5))
    for data, label in [(baseline, "CPU baseline"), (offload, "eBPF+CXL offload")]:
        if data is None or len(data) == 0:
            continue
        xs = np.sort(data)
        ys = np.arange(1, len(xs) + 1) / len(xs)
        ax.plot(xs, ys, label=label)
    ax.axvline(SLOT_BUDGET_US, color="red", linestyle="--", label="0.5 ms slot")
    ax.axvline(710, color="gray", linestyle=":", label="Six Times CPU LDPC ~710µs")
    ax.set_xscale("log")
    ax.set_xlabel("Latency (µs)")
    ax.set_ylabel("CDF")
    ax.legend(fontsize=6)
    ax.set_title("Per-slot latency CDF")
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out_dir, f"latency_cdf.{ext}"), dpi=300)
    plt.close(fig)


def plot_breakdown(out_dir):
    components = ["ebpf_probe", "ringbuf", "daemon", "compute", "signal"]
    values = [1.7, 2.0, 5.0, 120.0, 3.0]
    fig, ax = plt.subplots(figsize=(3.5, 2.5))
    ax.bar(components, values, color="steelblue")
    ax.set_ylabel("Latency (µs)")
    ax.set_title("Offload path breakdown (representative)")
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out_dir, f"latency_breakdown.{ext}"), dpi=300)
    plt.close(fig)


def plot_numa_sensitivity(root, out_dir):
    files = [
        ("paper/results/numa_latency_0ns.csv", "0 ns"),
        ("paper/results/numa_latency_142ns.csv", "142 ns"),
        ("paper/results/numa_latency_255ns.csv", "255 ns"),
    ]
    labels, misses = [], []
    for path, label in files:
        full = os.path.join(root, path)
        if not os.path.exists(full):
            continue
        df = pd.read_csv(full)
        labels.append(label)
        misses.append(100.0 * df["deadline_miss"].mean())
    if not labels:
        return
    fig, ax = plt.subplots(figsize=(3.5, 2.5))
    ax.plot(labels, misses, marker="o")
    ax.set_xlabel("CXL emulated latency")
    ax.set_ylabel("Slot deadline miss rate (%)")
    ax.set_title("NUMA/CXL latency sensitivity")
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out_dir, f"numa_sensitivity.{ext}"), dpi=300)
    plt.close(fig)


def plot_architecture(out_dir):
    fig, ax = plt.subplots(figsize=(3.5, 2.0))
    ax.axis("off")
    text = (
        "L1 sim → eBPF uprobe → ringbuf → GPU daemon\n"
        "↕ CXL shared memory (/dev/dax or mmap fallback)"
    )
    ax.text(0.5, 0.5, text, ha="center", va="center", fontsize=9,
            family="monospace")
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out_dir, f"architecture_diagram.{ext}"), dpi=300)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--offload", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    root = os.path.abspath(os.path.join(args.output_dir, "..", ".."))

    baseline = load_latency(args.baseline) if os.path.exists(args.baseline) else None
    offload = load_latency(args.offload) if os.path.exists(args.offload) else None

    plot_cdf(baseline, offload, args.output_dir)
    plot_breakdown(args.output_dir)
    plot_numa_sensitivity(root, args.output_dir)
    plot_architecture(args.output_dir)
    print(f"Figures written to {args.output_dir}")


if __name__ == "__main__":
    main()
