#define _GNU_SOURCE
#include "../ebpf/l1_intercept.h"
#include "../gpu_daemon/cxl_memory.h"
#include "../l1_sim/fft.h"
#include "../l1_sim/ldpc.h"

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

static cxl_ctx_t g_cxl;
static int g_cxl_ready;
static int g_offload_enabled;
static pthread_once_t g_once = PTHREAD_ONCE_INIT;

static void init_cxl(void)
{
	const char *path = getenv("CXL_DEV_PATH");

	if (!path)
		path = "/dev/dax0.0";

	if (cxl_init(&g_cxl, path) < 0)
		cxl_init_shm_fallback(&g_cxl);
	g_cxl_ready = 1;
}

static int send_offload_event(const struct offload_event *event)
{
	const char *sock_path = getenv("GPU_DAEMON_SOCKET");
	int fd;
	struct sockaddr_un addr;

	if (!sock_path)
		sock_path = "/tmp/gpu_daemon.sock";

	fd = socket(AF_UNIX, SOCK_STREAM, 0);
	if (fd < 0)
		return -errno;

	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strncpy(addr.sun_path, sock_path, sizeof(addr.sun_path) - 1);

	if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		close(fd);
		return -errno;
	}

	if (write(fd, event, sizeof(*event)) != (ssize_t)sizeof(*event)) {
		close(fd);
		return -EIO;
	}
	close(fd);
	return 0;
}

static int wait_gpu_done(uint32_t timeout_ms)
{
	cxl_ctrl_block_t *ctrl = cxl_get_ctrl(&g_cxl);
	struct timespec start, now;

	clock_gettime(CLOCK_MONOTONIC, &start);
	while (!ctrl->gpu_done) {
		clock_gettime(CLOCK_MONOTONIC, &now);
		uint64_t elapsed_ms = (uint64_t)(now.tv_sec - start.tv_sec) * 1000ULL +
				      (uint64_t)(now.tv_nsec - start.tv_nsec) / 1000000ULL;

		if (elapsed_ms > timeout_ms)
			return -ETIMEDOUT;
		usleep(50);
	}
	return 0;
}

int l1_offload_try(uint32_t work_type, const void *params)
{
	if (!g_offload_enabled)
		return -1;

	pthread_once(&g_once, init_cxl);
	if (!g_cxl_ready)
		return -1;

	cxl_ctrl_block_t *ctrl = cxl_get_ctrl(&g_cxl);

	ctrl->gpu_done = 0;
	ctrl->l1_ready = 0;
	ctrl->work_type = work_type;

	if (work_type == WORK_TYPE_LDPC) {
		const ldpc_params_t *p = params;

		memcpy(cxl_get_input_buf(&g_cxl), p->input, p->input_len);
		ctrl->input_offset = CXL_REGION_L1_INPUT_OFF;
		ctrl->input_len = p->input_len;
		ctrl->output_offset = CXL_REGION_GPU_OUTPUT_OFF;
		ctrl->output_len = p->output_len;
	} else if (work_type == WORK_TYPE_FFT) {
		const fft_params_t *p = params;
		size_t bytes = p->N * sizeof(float complex);

		memcpy(cxl_get_input_buf(&g_cxl), p->input, bytes);
		ctrl->input_offset = CXL_REGION_L1_INPUT_OFF;
		ctrl->input_len = bytes;
		ctrl->output_offset = CXL_REGION_GPU_OUTPUT_OFF;
		ctrl->output_len = bytes;
	} else {
		return -1;
	}

	struct offload_event ev = {
		.work_type = work_type,
		.pid = (uint32_t)getpid(),
		.input_addr = CXL_REGION_L1_INPUT_OFF,
		.output_addr = CXL_REGION_GPU_OUTPUT_OFF,
		.input_len = ctrl->input_len,
		.output_len = ctrl->output_len,
	};

	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);
	ctrl->timestamp_l1 = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
	ctrl->l1_ready = 1;

	if (send_offload_event(&ev) < 0)
		return -1;

	if (wait_gpu_done(500) < 0)
		return -1;

	if (work_type == WORK_TYPE_LDPC) {
		const ldpc_params_t *p = params;

		memcpy(p->output, cxl_get_output_buf(&g_cxl), p->output_len);
	} else if (work_type == WORK_TYPE_FFT) {
		const fft_params_t *p = params;

		memcpy(p->output, cxl_get_output_buf(&g_cxl),
		       p->N * sizeof(float complex));
	}

	return 0;
}

__attribute__((constructor))
static void offload_ctor(void)
{
	const char *env = getenv("RAN_OFFLOAD");

	g_offload_enabled = env && strcmp(env, "1") == 0;
}
