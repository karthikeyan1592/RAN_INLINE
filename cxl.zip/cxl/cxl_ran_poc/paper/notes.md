## Auto-generated Measurement Summary

Generated: 2026-06-13T12:46:23.101350

Emulation: qemu-cxl-type3

### Calibration Check

CPU LDPC large-TB baseline: 26.403 ms (target: ~0.71 ms)
Status: CHECK

### CPU-only baseline
- Mean per-slot latency: 4058283696437456.5 µs
- Slot deadline miss rate: 100.0%

### eBPF + CXL offload
- Mean per-slot latency: 8116567394906560.0 µs
- Slot deadline miss rate: 100.0%

### Novelty evidence
- L1 application lines changed for offload hook: 0 (weak symbol)
- eBPF intercept: ldpc_decode() / fft_process() boundaries
- Accelerator: CPU-based daemon (architecture proof)
